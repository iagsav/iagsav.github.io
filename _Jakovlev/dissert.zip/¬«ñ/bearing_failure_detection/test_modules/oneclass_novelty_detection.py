from os import listdir
from os.path import isfile, join

import matplotlib.pyplot as plt
import numpy as np
from sklearn import svm

import dataprovider as dp
import uform as uf

SOURCE_DIR='D:\\Research\\bearing_IMS\\2nd_test_split_and_normalized\\channel_{0}'
COLOURS=['red', 'green', 'blue', 'black']

def seek_folder(folder):
    print('Reading folder: ' + folder + '...')
    onlyfiles = [f for f in listdir(folder) if isfile(join(folder, f))]
    return onlyfiles


def train_on_each():
    clf = svm.OneClassSVM()

    for i in range(1, 4):
        train = []
        files = seek_folder(SOURCE_DIR.format(i))
        predictions = []
        aggregative_ratio = []
        for f_idx, file in enumerate(files):
            print('{0} part of {1} parts is processed \r'.format(f_idx, len(files)))
            chunk = dp.read_channel(
                join(SOURCE_DIR.format(i), str(file)))
            print('Calculating U-form...')
            u = [i for i in uf.uform(chunk)[1:]]
            train.append(u)
            print(u)
            if f_idx > 0:
                prediction = clf.predict(u)
                print(prediction)
                predictions.append(prediction[0])
                n_error_predictions = predictions.count(-1.0)
                if f_idx > 400:
                    aggregative_ratio.append(n_error_predictions / len(predictions))
            clf = clf.fit(np.asarray(train))
        plt.scatter(range(0, len(aggregative_ratio)), aggregative_ratio)
        plt.show()


def prep_train_set():

    for i in range(0, 4):
        train = []
        files = seek_folder(SOURCE_DIR.format(i))
        for f_idx, file in enumerate(files[:983]):
            print('{0} part of {1} parts is processed \r'.format(f_idx, len(files)))
            chunk = dp.read_channel(join(SOURCE_DIR.format(i), str(file)))
            print('Calculating U-form...')
            u = [round(i / 5) for i in uf.uform(chunk)[1:]]
            train.append(u)

        clf = svm.OneClassSVM(nu=0.6, kernel="rbf", gamma='auto')
        clf.fit(np.asarray(train))

        predictions = []
        aggregative_ratio = []
        files = seek_folder(SOURCE_DIR.format(i))
        for f_idx, file in enumerate(files):
            print('{0} part of {1} parts is processed \r'.format(f_idx, len(files)))
            chunk = dp.read_channel(join(SOURCE_DIR.format(i), str(file)))
            print('Calculating U-form...')
            u = np.asarray([round(i / 5) for i in uf.uform(chunk)[1:]])
            u = u.reshape(1, -1)
            print(u)
            prediction = clf.predict(u)
            print(prediction)
            predictions.append(prediction[0])
            n_error_predictions = predictions.count(-1.0)
            aggregative_ratio.append(n_error_predictions / len(predictions))
        plt.scatter(range(0, len(aggregative_ratio[400:])), aggregative_ratio[400:], c=COLOURS[i])


#train_on_each()
prep_train_set()

#include "makedatabasewindow.h"
#include "ui_makedatabasewindow.h"

MakeDatabaseWindow::MakeDatabaseWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MakeDatabaseWindow)
{
    ui->setupUi(this);
    dir = "";
    this->setFixedSize(this->size());
}

MakeDatabaseWindow::~MakeDatabaseWindow()
{
    delete ui;
}

void MakeDatabaseWindow::on_pushButtonBrowseDatabase_clicked()
{
    dir = QFileDialog::getExistingDirectory ( this, "Select Database Folder", QString(), QFileDialog::ShowDirsOnly);
    ui->lineEditDatabasePath->setText(dir);
}
//создание БД
void MakeDatabaseWindow::on_pushButtonMakeDatabase_clicked()
{
    //если не указана БД выдает ошибку
    if (dir.compare("") == 0)
    {
        QMessageBox messageBox(this);
        messageBox.setText("Specify database path!");
        messageBox.setWindowTitle("Error.");
        messageBox.exec();
        return;
    }


    //существует ли папка с БД
    QDir directory(dir);
    if(!directory.exists())
    {
        QMessageBox messageBox(this);
        messageBox.setText("No such directory!");
        messageBox.setWindowTitle("Error.");
        messageBox.exec();
        return;
    }

    //открывает файл БД для записи
    QFile databaseFile(dir + "/Database.txt");
    //если файл не отрылся выдает ошибку
    if(!databaseFile.open(QIODevice::WriteOnly))
    {
        QMessageBox messageBox(this);
        messageBox.setText("Can't open file!");
        messageBox.setWindowTitle("Error.");
        messageBox.exec();
        return;
    }
    //открывает текстовый поток
    QTextStream out(&databaseFile);
    //получает список файлов в паке с раширением jpg
    QStringList imagesFiles = directory.entryList(QStringList() << "*.jpg" << "*.JPG", QDir::Files);

    ui->progressBar->setValue(0); //установить значение прогресс-бара в 0
    //перебор фото в папке
    for(int i = 0; i < imagesFiles.count(); ++i)
    {
        QPoint eye1;
        QPoint eye2;

        QString imageName = imagesFiles[i]; //сохранение имени файла
        imageName.truncate(imageName.length() - 4); //отрезается от имени расширение
        QStringList eyesString = imageName.split('_'); //строка делится на части с разделителем _
        eye1.setX(eyesString[0].toInt()); //установка глаз исходя из имени
        eye1.setY(eyesString[1].toInt());
        eye2.setX(eyesString[2].toInt());
        eye2.setY(eyesString[3].toInt());


        QString imagePath = dir + "/" + imagesFiles[i]; //сохранение пути до файла

        QImage realImage(imagePath); //открытие файла
        unsigned int picSize = this->ui->comboBox->currentText().toInt();
        QImage transformatedImage = ImageVector::prepareImage(realImage, eye1, eye2, picSize); //трансформация фото

        ImageAttributes* attributes = ImageVector::calculateAttributes(transformatedImage);//вычисление признаков трансформированного фото
        out << imagesFiles[i] << "\n"; //запись в файл имени фото
        out << QString::number(attributes->getBlocksCount()*16) + "\n"; //запись в файл колличества блоков
        //перебор всех блоков
        for(int i = 0; i < attributes->getBlocksCount(); ++i)
        {
            //перебор всех признаков
            for(int j = 0; j < 16; ++j)
            {
                out << QString::number(attributes->getAttribute(i, j)) + "\n"; //запись в файл признаков
            }
        }

        delete attributes; //удаление признаков текуей фото
        ui->progressBar->setValue((int)(100./imagesFiles.count()*(i+1))); //установка прогресса в бар
    }
}

import dataprovider as dp
import matplotlib.pyplot as plt
import numpy as np
import uform as uf

SOURCE_FILE = 'D:\Research\\bearing_IMS\\2nd_test_uform_80\channel{0}_uform_80\\filter{1}.txt'
SOURCE_DIR = 'D:\Research\\bearing_IMS\\2nd_test_uform_80\channel0_uform_80\\'
FG_MASSES = 'D:\Research\\bearing_IMS\\2nd_test_masses\\masses{0}.txt'
# for j in range(1,15):
#     uform = dp.read_channel(SOURCE_FILE.format(0, j))
#     means = []
#     uform_part = uf.chunks(uform, 1500)
#     means = [sum(i) / len(i) for i in uform_part]
#     print(sum(means) / len(means))
#     plt.scatter(np.arange(len(means)), means)
#     plt.show()


#uf.analyze_groups(SOURCE_DIR)

for i in range(0, 34):
    fg = dp.read_channel(FG_MASSES.format(i))

    plt.scatter(np.arange(len(fg)), fg)
    plt.show()





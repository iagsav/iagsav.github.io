#include "imageattributes.h"
//конструктор
ImageAttributes::ImageAttributes(int blocks)
{
    blocksCount = blocks;

    attributes = new double*[blocksCount];
    for (int i = 0; i < blocksCount; ++i)
    {
        attributes[i] = new double[16];
    }
}
//деструктор
ImageAttributes::~ImageAttributes()
{
    //удаление двумерного массива
    for (int i = 0; i < blocksCount; ++i)
    {
        delete [] attributes[i];
    }
    delete [] attributes;
}
//установка признаков
void ImageAttributes::setAttribute(int blockNumber, int filterNumber, double filter)
{

    attributes[blockNumber][filterNumber] = filter;
}

double ImageAttributes::getAttribute(int blockNumber, int filterNumber)
{
    return attributes[blockNumber][filterNumber];
}
int ImageAttributes::getBlocksCount()
{
    return blocksCount;
}

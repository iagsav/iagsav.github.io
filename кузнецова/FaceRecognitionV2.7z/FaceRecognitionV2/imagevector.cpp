#include "imagevector.h"

ImageVector::ImageVector(QImage imageBase, QPoint eye1, QPoint eye2)
{
    this->imageBase = imageBase;

    filters[0] = 0xFFFF;
    filters[1] = 0x3333;
    filters[4] = 0x6666;
    filters[9] = 0xAAAA;
    filters[2] = 0xFF00;
    filters[3] = 0x33CC;
    filters[6] = 0x6699;
    filters[11] = 0xAA55;
    filters[5] = 0x0FF0;
    filters[7] = 0xC33C;
    filters[8] = 0x9669;
    filters[13] = 0x5AA5;
    filters[10] = 0x0F0F;
    filters[12] = 0xC3C3;
    filters[14] = 0x9696;
    filters[15] = 0x5A5A;

    this->imageGrey = QImage(PIC_SIZE, PIC_SIZE, QImage::Format_RGB32);
    this->imageTransformated = QImage(PIC_SIZE, PIC_SIZE, QImage::Format_RGB32);

    this->eye1.setX(eye1.x());
    this->eye1.setY(eye1.y());

    this->eye2.setX(eye2.x());
    this->eye2.setY(eye2.y());

    for(int i = 0; i < 4; ++i)
        for(int j = 0; j < 4; ++j)
            this->matrix16[i][j] = 0;

    for(int i = 0; i < 4; ++i)
        for(int j = 1; j < 16; ++j)
            this->filteredMatrix[i][j] = 0;
}

void ImageVector::ProcessImage()
{
    qDebug() << "Current Eye Point 1: " << eye1.x() << eye1.y();
    qDebug() << "Current Eye Point 2: " << eye2.x() << eye2.y();

    QPoint p(eye2.x() - eye1.x(), eye2.y() - eye1.y());

    double angle = -1 * atan2(p.y(), p.x());
    double scale = (PIC_SIZE / 3) / sqrt(p.x() * p.x() + p.y() * p.y());
    qDebug() << "Calculated scale: " << scale;
    qDebug() << "Calculated angle: " << (angle / 3.1415) * 360;

    // ------------ STEP 2 ------------------- //
    imageTransformated.fill(Qt::white);

    for (int x = 0; x < imageTransformated.size().width(); ++x)
    {
        for (int y = 0; y < imageTransformated.size().height(); ++y)
        {
            double x1 = (x - imageTransformated.size().width() / 4); // сдвигаем итоговое изображения тaк, чтобы глаз оказался в нуле
            double y1 = (y - imageTransformated.size().height() / 3);

            double x2 = x1 / scale; // масштабируем в обратную сторону
            double y2 = y1 / scale;

            double x3 = x2 * cos(-angle) - y2 * sin(-angle); // поворачиваем в обратную сторону
            double y3 = x2 * sin(-angle) + y2 * cos(-angle);

            double x4 = x3 + eye1.x(); // ставим глаз в исходное положение
            double y4 = y3 + eye1.y();

            int xFin = (int)round(x4);
            int yFin = (int)round(y4);

            if (((xFin >= 0) && (xFin < imageBase.size().width())) && ((yFin >= 0) && (yFin < imageBase.size().height())))
                imageTransformated.setPixel(x, y, imageBase.pixel(xFin, yFin));

        }

    }

    qDebug() << "Image transformated";

    // ------------ STEP 3 ----------- //
    int min = 256;
    int max = -1;
    for (int x = 0; x < imageTransformated.size().width(); ++x)
    {
        for (int y = 0; y < imageTransformated.size().height(); ++y)
        {

           QRgb qRgb = imageTransformated.pixel(x,y);
          // int newRgb = (qBlue(qRgb) + qRed(qRgb) + qGreen(qRgb)) / 3;
           int newRgb = qGray(qRed(qRgb), qGreen(qRgb), qBlue(qRgb));
           QColor c = QColor(newRgb, newRgb, newRgb);
           imageGrey.setPixelColor(x, y, c);

           if (newRgb < min)
               min = newRgb;

           if (newRgb > max)
               max = newRgb;
        }
    }
    max -= min;

    qDebug() << "Image setted grey /w min/max";

    QVector<QImage> parts;
    for(int i = 0; i < PIC_PART; ++i)
    {
        for(int j = 0; j < PIC_PART; ++j)
        {
            QImage image = imageGrey.copy(i*(imageGrey.size().width()/PIC_PART), j*(imageGrey.size().height()/PIC_PART), imageGrey.size().width()/PIC_PART, imageGrey.size().height()/PIC_PART);
            parts.push_back(image);
        }
    }

    qDebug() << "Image divided into " << parts.size() << " parts";

    for(int m = 0; m < parts.size(); ++m)
    {
        for (int i = 0; i < 4; ++i)
            for(int j = 0; j < 4; ++j)
                matrix16[i][j] = 0;

        for (int x = 0; x < parts[m].size().width(); ++x)
        {
            for (int y = 0; y < parts[m].size().height(); ++y)
            {
                QRgb qrgb =  parts[m].pixel(x,y);
                matrix16[x/(parts[m].size().width()/4)][y/(parts[m].size().height()/4)] += (double)(qRed(qrgb) - min)/(double)max;
            }
        }

        double sumF = 0;
        for (int f = 1; f < 16; ++f)
        {
            sumF = 0;
            for (int i = 0; i < 4; ++i)
            {
                for (int j = 0; j < 4; ++j)
                {
                    if (((filters[f] >> (j*4+i)) & 0x01) == 0x01)
                        sumF += matrix16[i][j];
                    else
                        sumF -= matrix16[i][j];

                }
            }

            filteredMatrix[m][f] = sumF;
        }
    }

    qDebug() << "Image parts calculated";
}

QImage ImageVector::getImageBase()
{
    return imageBase;
}


QImage ImageVector::getImageTransformated()
{
    return imageTransformated;
}


QImage ImageVector::getImageGrey()
{
    return imageGrey;
}


double ImageVector::GetImageVector(int part, int filterNumber)
{
    return filteredMatrix[part][filterNumber];
}

int ImageVector::GetImagerParts()
{
    return PIC_PART*PIC_PART;
}

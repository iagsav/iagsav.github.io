print(__doc__)

import matplotlib.pyplot as plt
import numpy as np
from sklearn.svm import SVR
from matplotlib import rc

font = {'family': 'Verdana',
        'weight': 'normal'}
rc('font', **font)

###############################################################################
# Generate sample data
X = np.sort(5 * np.random.rand(40, 1), axis=0)
y = np.sin(X).ravel()

###############################################################################
# Add noise to targets
y[::5] += 3 * (0.5 - np.random.rand(8))

###############################################################################
# Fit regression model
svr_rbf = SVR(kernel='rbf', C=1e3, gamma=0.1)
svr_lin = SVR(kernel='linear', C=1e3)
svr_poly = SVR(kernel='poly', C=1e3, degree=2)
y_rbf = svr_rbf.fit(X, y).predict(X)
y_lin = svr_lin.fit(X, y).predict(X)
y_poly = svr_poly.fit(X, y).predict(X)

###############################################################################
# look at the results
plt.scatter(X, y, c='k', label='данные')
plt.hold('on')
plt.plot(X, y_rbf, c='g', label='Радиальная базовая функция ядра')
plt.plot(X, y_lin, c='r', label='Линейная функция ядра')
plt.plot(X, y_poly, c='b', label='Полиномиальная функция ядра')
plt.xlabel('х')
plt.ylabel('у')
plt.title('Support Vector Regression')
plt.legend()
plt.show()
#ifndef IMAGEATTRIBUTES_H
#define IMAGEATTRIBUTES_H

//класс хранит признаки одной фото
class ImageAttributes
{
public:
    ImageAttributes(int blocks); //конструктор
    ~ImageAttributes(); //деструктор
    void setAttribute(int blockNumber, int filterNumber, double filter); //установка признака
    double getAttribute(int blockNumber, int filterNumber); //удаление признака
    int getBlocksCount(); //получение кол-ва блоков

private:
    double** attributes; //двумерный массив хранения признаков
    int blocksCount; //кол-во блоков
};

#endif

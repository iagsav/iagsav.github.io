#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include <QMouseEvent>
#include "imageattributes.h"
#include "imagevector.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void mouseReleaseEvent(QMouseEvent* event); //ункция обработки отпускания мыши в окне

private slots:
    void on_pushButtonBrowseDatabase_clicked();

    void on_buttonLoadImage_clicked();

    void on_buttonSearch_clicked();

    void on_buttonSelectEyes_clicked();

private:
    Ui::MainWindow *ui; //пременная для доступа к элементам окна
    QString dir; //строка содержащая путь до БД в системе
    QImage* givenImage; //указатель на загружаемое изображение

    double scaleCoeffX; //коэффициенты масштабирования для правильного указания глаз
    double scaleCoeffY; //определяют соотношения между изображением внутри виджета и реальным

    ImageAttributes* attributes; //хранит признаки искомой фотографии

    bool isEyePointing; //включен ли режим указания глаз
    QPoint* eye1; //указатели на точки глаз
    QPoint* eye2;
};

#endif // MAINWINDOW_H

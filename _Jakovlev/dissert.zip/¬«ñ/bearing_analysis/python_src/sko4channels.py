import dataprovider as dp
import matplotlib.pyplot as plt
import numpy as np
from sklearn import svm

# TODO: Remove dependencies if possible;
# TODO: Make BASE_DIR, SOURCE_FILE, TRAIN_SET_SIZE, SVM options script parameters to get it executed from Java


SOURCE_FILE = 'D:\Research\\bearing_IMS\\2nd_test_uform_80\channel3_uform_80\\dump.txt'
BASE_DIR = 'D:\Research\\bearing_IMS\\2nd_test_uform_80\channel3_uform_80\\'
TRAIN_SET_SIZE = 500

# Threshold anaysis chunk size
CHUNK_SIZE = 30
YELLOW_THRESHOLD = .15
RED_THRESHOLD = .99

#Read data from the file
skos = dp.read_file(SOURCE_FILE)

graphs = []
test_sko = [x for x in skos[5]]

# Setup SVM with given parameters
clf = svm.OneClassSVM(nu=.01, kernel="rbf", gamma=1)
np.set_printoptions(threshold=np.nan)

# Split given data set into training set and the actual data set.
train = np.asarray(test_sko[:TRAIN_SET_SIZE])
train = train.reshape(-1, 1)
test = np.asarray(test_sko[TRAIN_SET_SIZE:])
test = test.reshape(-1, 1)

# Train the SVM
clf.fit(train)

# Classify values in the data set between regulars and novelties.
y_pred_test = clf.predict(test)

# Set figure size in inches
plt.figure(figsize=(18, 12))

# Show regulars in green and novelties in red
# First we need to separate two sets of data
reg_x = []
reg_y = []
nov_x = []
nov_y = []
for i, val in enumerate(test):
    if y_pred_test[i] == 1:
        reg_x.append(i + TRAIN_SET_SIZE)
        reg_y.append(val)
    else:
        nov_x.append(i + TRAIN_SET_SIZE)
        nov_y.append(val)

# Show train set in black
train_set = plt.scatter(np.arange(TRAIN_SET_SIZE), train, c='k')
# Regulars in green
regulars = plt.scatter(reg_x, reg_y, c='green')
# Novelties in red
novelties = plt.scatter(nov_x, nov_y, c='red')

yellow_thresh = None
red_thresh = None

# Find where does warning and critical borders are
for i, val in enumerate(test[CHUNK_SIZE:]):
    nov_num = 0
    for j in range(0, CHUNK_SIZE):
        if y_pred_test[i + CHUNK_SIZE - j] == -1:
            nov_num+=1
    nov_ratio = nov_num/CHUNK_SIZE
    if (nov_ratio > RED_THRESHOLD) and (red_thresh is None):
        red_thresh = i + TRAIN_SET_SIZE
    if (nov_ratio > YELLOW_THRESHOLD) and (yellow_thresh is None):
        yellow_thresh = i + TRAIN_SET_SIZE

# Plot the figure
plt.legend([train_set, regulars, novelties],
           ["Train Set", "Regulars", "Novelties"], loc=2)
if yellow_thresh is not None:
    yellow_zone = plt.axvline(yellow_thresh,c='yellow', lw=3)
    plt.legend([yellow_zone], ["Warning"], loc=3)
if red_thresh is not None:
    red_zone = plt.axvline(red_thresh, c='red', lw=3)
    plt.legend([red_zone], ["Critical"], loc=4)

# Save figure to file with given resolution (dpi)
plt.savefig(BASE_DIR + 'figure.png', bbox_inches='tight', dpi=250)
plt.show()

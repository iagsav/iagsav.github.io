package nntu.oyakov;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by oyakov on 31.10.2016.
 */
public class DataChannel {

    private List<List<Double>> filters;

    public List<List<Double>> getFilters() {
        return filters;
    }

    public void setFilters(List<List<Double>> filters) {
        this.filters = filters;
    }

    private List<List<Double>> uforms;

    public List<List<Double>> getUforms() {
        return uforms;
    }

    public void setUforms(List<List<Double>> uforms) {
        this.uforms = uforms;
    }

    private DataChannel(List<List<Double>> filters) {
        this.filters = filters;
        uforms = new ArrayList<>();

        int filt_size = this.filters.get(0).size();

        for (int i = 0; i < filt_size - 1; i++) {
            List<Double> elem = new ArrayList<>();
            for (int j = 0; j < 16; j++) {
                elem.add(filters.get(j).get(i));
            }

            this.uforms.add(elem);
        }
    }

    public static DataChannel loadChannel(String channelFolder) {

        List<List<Double>> filters = new ArrayList<>();

        File data_folder = new File(channelFolder);
        System.out.println("Processing data folder: " + channelFolder);

        // Get all U-form filter data from the folder for the certain channel
        List<String> data_files = new LinkedList<>(Arrays.asList(data_folder.list()));
        data_files.removeIf((a) -> !a.startsWith("filter"));

        for(int i = 0; i < data_files.size(); i++) {
            filters.add(new ArrayList<>());
        }

        // Load each filter into the filter array object
        for (String file: data_files) {
            Path path = FileSystems.getDefault().getPath(channelFolder, file);
            System.out.println("Processing file #" + data_files.indexOf(file));
            try {
                List <String> strings = Files.lines(path).collect(Collectors.toList());
                for(String str : strings) {
                    StringTokenizer tok = new StringTokenizer(str, " ", false);
                    while(tok.hasMoreTokens()) {
                        Double val = Double.parseDouble(tok.nextToken());
                        filters.get(data_files.indexOf(file)).add(val);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return new DataChannel(filters);
    }
}

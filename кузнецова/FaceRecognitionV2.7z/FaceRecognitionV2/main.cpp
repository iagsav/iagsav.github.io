#include "mainwindow.h"
#include "makedatabasewindow.h"
#include <QApplication>
#include <QString>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QMainWindow* w = NULL;
    // открытие второго окна по ключу s
    if ((argc == 2) && (QString(argv[1]).compare("-s", Qt::CaseInsensitive) == 0))
        w = new MakeDatabaseWindow();
    else
        w = new MainWindow();

    w->show();

    int result = a.exec();
    delete w;

    return result;
}

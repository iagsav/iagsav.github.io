#include "mainwindow.h"
#include "ui_mainwindow.h"
//конструктор окна
MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this); //инициализируется графический интерфейс
    dir = "";
    this->setFixedSize(this->size());
    givenImage = NULL;

    scaleCoeffX = 0;
    scaleCoeffY = 0;

    isEyePointing = false;
    eye1 = NULL;
    eye2 = NULL;

    attributes = NULL;
}
//деструктор
MainWindow::~MainWindow()
{
    if (givenImage != NULL)//удаление загруженной фотографии из памяти
        delete givenImage;

    delete ui; //удаляется графический интерфейс
}

void MainWindow::mouseReleaseEvent(QMouseEvent* event)
{
    if (!isEyePointing)
        return;

    QPoint point = this->ui->mainImage->pos(); //верхний левый угол виджета фотографии
    QSize labelSize = this->ui->mainImage->size(); //размер виджета
    //произошло нажатие на виджет или нет
    bool isPictureClick = true;
    isPictureClick &= (event->x() > point.x());
    isPictureClick &= (event->y() > point.y());
    isPictureClick &= (event->x() < point.x() + labelSize.width());
    isPictureClick &= (event->y() < point.y() + labelSize.height());

    if (isPictureClick)
    {
        if (eye1 == NULL)
        {
           eye1 = new QPoint();
           eye1->setX(event->x() - point.x());
           eye1->setY(event->y() - point.y());
        }
        else if (eye2 == NULL)
        {
            eye2 = new QPoint();
            eye2->setX(event->x() - point.x());
            eye2->setY(event->y() - point.y());
            isEyePointing = false;

            QPoint realEye1; //глаза на фотографии в памяти
            QPoint realEye2;


            realEye1.setX(scaleCoeffX * eye1->x());
            realEye1.setY(scaleCoeffY * eye1->y());

            realEye2.setX(scaleCoeffX * eye2->x());
            realEye2.setY(scaleCoeffY * eye2->y());


            unsigned int picSize = this->ui->comboBox->currentText().toInt();
            //вызов функции трансформации
            QImage processed = ImageVector::prepareImage(*givenImage, realEye1, realEye2, picSize);
            //если коэффициенты были созданны, удалить
            if (attributes != NULL)
                delete attributes;
            //вызов функции рассчета признаков
            attributes = NULL;
            attributes = ImageVector::calculateAttributes(processed);
            //удаление первого глаза
            if (eye1 != NULL)
                delete eye1;
            eye1 = NULL;
            //удаление второго глаза
            if (eye2 != NULL)
                delete eye2;
            eye2 = NULL;
        }

    }

}
//функция выбора БД
void MainWindow::on_pushButtonBrowseDatabase_clicked()
{
    dir = QFileDialog::getExistingDirectory ( this, "Select Database Folder", QString(), QFileDialog::ShowDirsOnly); //открытие диалога с папками системы
    ui->lineEditDatabasePath->setText(dir); //строчку пути выводит на виджет
}
//функция нажатия на кнопку загрузить изображение
void MainWindow::on_buttonLoadImage_clicked()
{
    if (givenImage != NULL)
        delete givenImage;

    QString file = QFileDialog::getOpenFileName(this, "Select image", "", "*.jpg *.JPG"); //выбор файла
    givenImage = new QImage(file); //загружаем фотографию в память
    QImage scaledGrey = givenImage->scaled(this->ui->mainImage->size(), Qt::KeepAspectRatio); //масштабируем фото по размеру виджета
    //устанавливаем коэффициенты масштабирования
    scaleCoeffX = ((double)givenImage->size().width() / (double)scaledGrey.size().width());
    scaleCoeffY = ((double)givenImage->size().height() / (double)scaledGrey.size().height());

    ui->mainImage->setPixmap(QPixmap::fromImage(scaledGrey)); //вывод преобразованной фото в виджет

    if (attributes != NULL)
        delete attributes;

    attributes = NULL;
}

void MainWindow::on_buttonSearch_clicked()
{
    //проверка указана ли БД
    if (dir.compare("") == 0)
    {
        QMessageBox messageBox(this);
        messageBox.setText("Specify database path!");
        messageBox.setWindowTitle("Error.");
        messageBox.exec();
        return;
    }
    //указаны ли глаза
    if (attributes == NULL)
    {
        QMessageBox messageBox(this);
        messageBox.setText("Specify eyes first!");
        messageBox.setWindowTitle("Error.");
        messageBox.exec();
        return;
    }

    QFile databaseFile(dir + "/Database.txt"); //открытие файла БД
    //удалось ли открыть файл БД
    if(!databaseFile.open(QIODevice::ReadWrite))
    {
        QMessageBox messageBox(this);
        messageBox.setText("Can't open file!");
        messageBox.setWindowTitle("Error.");
        messageBox.exec();
        return;
    }
    //открытие текстового потока
    QTextStream in(&databaseFile);
    //контейнер сортированнй по ключу для хранения путей похожих фотографий
    QMap<double, QString> files; //дельта; путь до фотографии в системе
    double currentDelta = 0; //хранит дельту между загруженным фото и текущей фото из БД

    QString blocksNumber; //колличество блоков на 1 фото
    QString temp; //временная переменная
    QString fileName; //путь до текущей фото в БД
    //пока не кончилась БД
    while(!databaseFile.atEnd() || !in.atEnd())
    {
       // qDebug() << "Pos: " << databaseFile.pos();
        fileName = in.readLine(); //считывание имени текущей фото в БД
       // qDebug() << "Pos: " << databaseFile.pos();
       // qDebug() << "File name: " << fileName;
        blocksNumber = in.readLine(); //считывание колличества блоков

       // qDebug() << "Filename: " << fileName;
        currentDelta = 0; //обнуляем дельту
       // qDebug() << "Current blocks: " << blocksNumber.toInt();
       // qDebug() << "Attributes blocks: " << (attributes->getBlocksCount()*16);
        //qDebug() << "Pos: " << databaseFile.pos();
        //совпадает ли кол-во блоков в БД с кол-вом блоков в загруженном изображении
        if (blocksNumber.toInt() == (attributes->getBlocksCount()*16))
        {
            //перебирает номера блоков
            for(int i = 0; i < attributes->getBlocksCount(); ++i)
            {
                //перебирает номера ячеек фильтров
                for(int j = 0; j < 16; ++j)
                {
                    //считывает из БД значение ячейки
                    temp = in.readLine();
                    //qDebug() << "Pos: " << databaseFile.pos();
                    //if ((temp.toDouble()*attributes->getAttribute(i, j)) > 0)
                       // currentDelta += abs(temp.toDouble() - attributes->getAttribute(i, j));
                    currentDelta += ((temp.toDouble()*attributes->getAttribute(i,j)>0) ? 0 : 1); //увеличивает или уменьшает дельту в зависимости от значений признаков
                }
            }

            files.insert(currentDelta, fileName); //вставляет каждую фото в контейнер путей похожих фото
            //даляет фото из контейнера, если его размер больше 9
            if (files.size() > 9)
                files.remove(files.lastKey());
        }
        else
        {
            qDebug() << "Skip: " << fileName << " because filters count not euqal";
            for(int i = 0; i < blocksNumber.toInt(); ++i)
                temp = in.readLine(); //читает в холостую
        }
        qDebug() << "Pos: " << databaseFile.pos();
    }

    qDebug() << "Similar images count: " << files.size();
    QList<QString> similarImages = files.values(); //массив путей похожих фотографий
    QList<double> deltas = files.keys(); //массив дельт похожих фото
    qDebug() << deltas;
    //если кол-во похожих больше 0
    if (similarImages.size() > 0)
    {
        //вставляет фото в соответствущий виджет
        QImage test(dir + "/" + similarImages.at(0)); //открытие фото
        QImage scaledGrey = test.scaled(this->ui->mainImage_2->size(), Qt::KeepAspectRatio); //масштабирование
        ui->mainImage_2->setPixmap(QPixmap::fromImage(scaledGrey)); //отображение на виджете

        if (similarImages.size() > 1)
        {
            QImage test(dir + "/" + similarImages.at(1));
            QImage scaledGrey = test.scaled(this->ui->similarImage1->size(), Qt::KeepAspectRatio);
            ui->similarImage1->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 2)
        {
            QImage test(dir + "/" + similarImages.at(2));
            QImage scaledGrey = test.scaled(this->ui->similarImage2->size(), Qt::KeepAspectRatio);
            ui->similarImage2->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 3)
        {
            QImage test(dir + "/" + similarImages.at(3));
            QImage scaledGrey = test.scaled(this->ui->similarImage3->size(), Qt::KeepAspectRatio);
            ui->similarImage3->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 4)
        {
            QImage test(dir + "/" + similarImages.at(4));
            QImage scaledGrey = test.scaled(this->ui->similarImage4->size(), Qt::KeepAspectRatio);
            ui->similarImage4->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 5)
        {
            QImage test(dir + "/" + similarImages.at(5));
            QImage scaledGrey = test.scaled(this->ui->similarImage5->size(), Qt::KeepAspectRatio);
            ui->similarImage5->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 6)
        {
            QImage test(dir + "/" + similarImages.at(6));
            QImage scaledGrey = test.scaled(this->ui->similarImage6->size(), Qt::KeepAspectRatio);
            ui->similarImage6->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 7)
        {
            QImage test(dir + "/" + similarImages.at(7));
            QImage scaledGrey = test.scaled(this->ui->similarImage7->size(), Qt::KeepAspectRatio);
            ui->similarImage7->setPixmap(QPixmap::fromImage(scaledGrey));
        }

        if (similarImages.size() > 8)
        {
            QImage test(dir + "/" + similarImages.at(8));
            QImage scaledGrey = test.scaled(this->ui->similarImage8->size(), Qt::KeepAspectRatio);
            ui->similarImage8->setPixmap(QPixmap::fromImage(scaledGrey));
        }
    }
    else
    {
        qDebug() << "No in similar list";
    }

    databaseFile.close(); //закрытие файла БД
}
//включает режим указания глаз
void MainWindow::on_buttonSelectEyes_clicked()
{
    isEyePointing = true;
}

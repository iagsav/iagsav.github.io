import os
import sys
from os import listdir
from os.path import isfile, join

import dataprovider
import uform as uf

MEAN = 0.0
RAW_DATA_FOLDER = 'D:\\Research\\bearing_IMS\\2nd_test'
DATA_FOLDER = 'D:\\Research\\bearing_IMS\\2nd_test_10\\channel_{0}\\'
UFORM_OUTPUT_FOLDER = 'D:\\Research\\bearing_IMS\\2nd_test_uform_640\\channel{0}_uform_640\\'
CHUNK_TO_FILE_RATIO = 640
NUMBER_OF_CHANNELS = 4

if len(sys.argv) == 1:
    print('Proceeding with default values...')
elif len(sys.argv) == 4:
    print('Overriding default values...')
    RAW_DATA_FOLDER = sys.argv[2]
    DATA_FOLDER = sys.argv[3]
    UFORM_OUTPUT_FOLDER = sys.argv[4]
else:
    print('Incorrect number of arguments, please provide 0 or 3 arguments.')
    exit(1)

print('RAW_DATA_FOLDER = {0}'.format(RAW_DATA_FOLDER))
print('DATA_FOLDER = {0}'.format(DATA_FOLDER))
print('UFORM_OUTPUT_FOLDER = {0}'.format(UFORM_OUTPUT_FOLDER))


def dump(data, folder, filename, delim):
    if not os.path.exists(folder):
        os.makedirs(folder)
    with open(join(folder, filename), 'a', encoding='utf-8') as f:
        for piece in data:
            f.write(str(piece) + delim)


def dump_bin(data, filename='E:\wave pack\\dump.txt', delim="\n"):
    with open(filename, 'wb') as f:
        for piece in data:
            f.write(bytearray(str(piece) + delim, encoding='utf-8'))


def rotate(data):
    line = []
    res = []
    for i in range(len(data[0])):
        for piece in data:
            line += [piece[i]]
        res.append(line)
        line = []
    return res


def read_file(filename, delim='\t'):
    with open(filename, encoding='utf-8') as file:
        lines = [s.split(delim) for s in file.read().splitlines()]
        array = []
        channels = rotate(lines)
        for channel in channels:
            array.extend([[float(val) for val in channel if val != '']])
        return array


def read_channel(filename, delim=' '):
    with open(filename, encoding='utf-8') as file:
        lines = [s.split(delim) for s in file.read().splitlines()]
        array = []
        for line in lines:
            array += [float(val) for val in line if val != '']
        return array


def seek_folder(folder):
    print('Reading folder: ' + folder + '...')
    onlyfiles = [f for f in listdir(folder) if isfile(join(folder, f))]
    return onlyfiles


def mean(data):
    return sum(data) / len(data)


def prepare_data():
    # raw data read, parsed into the channels and is written into the filesystem
    dataprovider.read_and_provide_channels(raw_data_folder=RAW_DATA_FOLDER, prep_data_folder=DATA_FOLDER)


def extract_features():
    for i in range(0, NUMBER_OF_CHANNELS):
        files = seek_folder(DATA_FOLDER.format(i))

        for f_idx, file in enumerate(files):
            print('{0} part of {1} parts is processed'.format(f_idx, len(files)), end='\r')
            chunk = read_channel(join(DATA_FOLDER.format(i), str(file)))
            u = uf.uform_dec(chunk, CHUNK_TO_FILE_RATIO)
            D = rotate(u)
            for fil_idx, filtr in enumerate(D):
                dump(filtr, UFORM_OUTPUT_FOLDER.format(i), 'filter{0}.txt'.format(fil_idx), delim=' ')


# ###########MAIN FLOW###############################

extract_features()
exit(0)

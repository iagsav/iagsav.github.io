"""
Simple demo of a scatter plot.
"""
import matplotlib.pyplot as plt
import numpy as np
import dataprovider as dp

N = 16
x = np.arange(16)
y = (np.random.rand(N).round(1) ) * 10
#area = np.pi * (15 * np.random.rand(N))**2  # 0 to 15 point radii
axes = plt.gca()

axes.set_xlim([-1, 15.5])
axes.set_ylim([-1.5, 11])
axes.spines['left'].set_position('zero')
axes.spines['right'].set_color('none')
axes.spines['bottom'].set_position('zero')
axes.spines['top'].set_color('none')
plt.yticks(np.arange(1, 12, 1))
plt.scatter(x, y, c='k', alpha=1)
plt.show()
#ifndef MAKEDATABASEWINDOW_H
#define MAKEDATABASEWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QMessageBox>
#include "imageattributes.h"
#include "imagevector.h"

namespace Ui {
class MakeDatabaseWindow;
}

class MakeDatabaseWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MakeDatabaseWindow(QWidget *parent = 0);
    ~MakeDatabaseWindow();

private slots:
    void on_pushButtonBrowseDatabase_clicked();

    void on_pushButtonMakeDatabase_clicked();

private:
    Ui::MakeDatabaseWindow *ui;
    QString dir;
};

#endif // MAKEDATABASEWINDOW_H

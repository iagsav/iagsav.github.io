import uform as uf
from sklearn import svm
from os import listdir
from os.path import isfile, join
import numpy as np
import matplotlib.pyplot as plt
import dataprovider as dp

RAW_DATA = 'C:\\Research\\bearing_IMS\\2nd_test'

STATS_FILENAME = join(RAW_DATA, 'stats.txt')
MEANS_FILENAME = join(RAW_DATA, 'means{0}.txt')
MSR_FILENAME = join(RAW_DATA, 'msr.txt')


def seek_folder(folder):
    print('Reading folder: ' + folder + '...')
    onlyfiles = [f for f in listdir(folder) if isfile(join(folder, f))]
    return onlyfiles


def display_stats():
    mins = [2.0, 2.0, 2.0, 2.0]
    maxs = [-2.0, -2.0, -2.0, -2.0]
    mean = [0.0, 0.0, 0.0, 0.0]
    means = [[], [], [], []]
    files = seek_folder(RAW_DATA)
    for f_idx, file in enumerate(files):
        print('Reading file {0}'.format(f_idx))
        channels = dp.read_file(join(RAW_DATA, file), delim='\t')
        for chann_idx, channel in enumerate(channels):
            for value in channel:
                if value < mins[chann_idx]:
                    mins[chann_idx] = value
                if value > maxs[chann_idx]:
                    maxs[chann_idx] = value
            local_mean = round(sum(channel) / len(channel), 3)
            means[chann_idx].append(local_mean)
            mean[chann_idx] = round((mean[chann_idx] + (sum(channel) / len(channel))) / 2, 3)

    print(mean)
    print(mins)
    print(maxs)

    with open(STATS_FILENAME, 'a', encoding='utf-8') as stats:
        stats.write(str(mean))
        stats.write(str(mins))
        stats.write(str(maxs))
    for channel_idx, channel in enumerate(means):
        with open(MEANS_FILENAME.format(channel_idx), 'a', encoding='utf-8') as stats:
            for value in means[channel_idx]:
                stats.write(str(value))




display_stats()

package nntu.oyakov;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by oyakov on 27.02.2017.
 */
public class DataHelper {

    /* Split vector @list into chunks of size @batchSize */
    public static List<List<Double>> partition_vector(List<Double> list, final int batchSize)
    {
        assert(batchSize > 0);
        assert(list != null);
        assert(list.size() + batchSize <= Integer.MAX_VALUE); //avoid overflow

        int idx;

        List<List<Double>> result = new ArrayList<>();

        for (idx = 0; idx + batchSize <= list.size(); idx += batchSize) {
            result.add(list.subList(idx, idx + batchSize));
        }
        if (idx < list.size()) {
            result.add(list.subList(idx, list.size()));
        }

        return result;
    }

    /* Split matrix @matrix into chunks of size @batchSize */
    public static List<List<List<Double>>> partition_matrix(List<List<Double>> matrix, final int batchSize)
    {
        assert(batchSize > 0);
        assert(matrix != null);
        assert(matrix.size() + batchSize <= Integer.MAX_VALUE); //avoid overflow

        int idx;

        List<List<List<Double>>> result = new ArrayList<>();

        for (idx = 0; idx + batchSize <= matrix.size(); idx += batchSize) {
            result.add(matrix.subList(idx, idx + batchSize));
        }
        if (idx < matrix.size()) {
            result.add(matrix.subList(idx, matrix.size()));
        }

        return result;
    }

    public static Double mean(List<Double> data) {
        double sum = 0;
        for(Double value: data) {
            sum += value;
        }
        return sum / data.size();
    }

    public static Double sko(List<Double> data) {
        double m = mean(data);
        double sum = 0.0;
        for (double value : data) {
            sum += (value - m) * (value - m);
        }
        Double dispersion = sum / data.size();
        return Math.sqrt(dispersion);
    }

    public static List<Double> mean_16(List<List<Double>> data) {
        List<Double> sum = new ArrayList<>(16);

        for (int i = 0; i < 16; i++) {
            sum.add(0.0);
        }

        for(List<Double> value: data) {
            for (int i = 0; i < 16; i++) {
                sum.set(i, sum.get(i) + value.get(i));
            }
        }

        for (int i = 0; i < 16; i++) {
            sum.set(i, sum.get(i) / data.size());
        }

        return sum;
    }

    // Calculate sko of a batch of 16-d vectors
    public static List<Double> sko_16(List<List<Double>> data) {
        List<Double> m = mean_16(data);
        List<Double> sum = new ArrayList<>(16);

        for (int i = 0; i < 16; i++) {
            sum.add(0.0);
        }

        for (List<Double> value : data) {
            List<Double> difference = new ArrayList<>(16);
            for (int i = 0; i < 16; i++) {
                difference.add((value.get(i) - m.get(i)) * (value.get(i) - m.get(i)));
            }

            for (int i = 0; i < 16; i++) {
                sum.set(i, sum.get(i) + difference.get(i));
            }
        }

        for (int i = 0; i < 16; i++) {
            sum.set(i, Math.sqrt(sum.get(i) / data.size()));
        }

        return sum;
    }
}

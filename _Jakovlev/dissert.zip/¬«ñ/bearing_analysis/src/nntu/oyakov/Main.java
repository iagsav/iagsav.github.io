package nntu.oyakov;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    private static final int NUMBER_OF_FILTERS = 16;

    private static String BASE_DIR = "D:\\Research\\bearing_IMS\\2nd_test_uform_80";
    private static String OUTPUT_FILE_NAME = "\\dump.txt";

    public static void main(String[] args) {

        // Detect the number of channels under the base folder and then analyze each one.

        File base_folder = new File(BASE_DIR);

        String[] subfolders = base_folder.list();

        System.out.println("BASE_DIR = " + BASE_DIR);
        System.out.println("Number of channels detected = " + subfolders.length);

        for (int i = 0; i < subfolders.length; i++) {
            analyze_channel(BASE_DIR + "\\" + subfolders[i]);
        }
    }

    public static void analyze_channel(String channel_dir) {
        // Read U-Form of the channel from the filesystem.
        DataChannel channel = DataChannel.loadChannel(channel_dir);

        // Calculate the features.
        List<List<Double>> sko_uforms = new ArrayList<>();

        List<List<List<Double>>> uform_partition = DataHelper.partition_matrix(channel.getUforms(), 30);
        sko_uforms.addAll(uform_partition.stream().map(DataHelper::sko_16).collect(Collectors.toList()));

        File dump_file = new File(channel_dir + OUTPUT_FILE_NAME);
        if (dump_file.exists()) {
            System.out.println("Dump file already exists, deleting it...");
            dump_file.delete();
        }

        // Write results (Standard Deviation of U-Form batches) to the file.
        try (PrintWriter writer = new PrintWriter(channel_dir + OUTPUT_FILE_NAME, "UTF-8")) {
            for (List<Double> sko : sko_uforms) {
                for (int i = 0; i < NUMBER_OF_FILTERS; i++) {
                    if (i != NUMBER_OF_FILTERS - 1)
                        writer.print(sko.get(i) + "\t");
                    else
                        writer.println(sko.get(i));
                }
            }

        } catch (Exception e) {
            System.out.println("Exception occurred during writing results to the file.");
            System.out.println(e);
        }

        System.out.println("Find the results in the following file:\n" + channel_dir + OUTPUT_FILE_NAME);
    }
}

#ifndef IMAGEVECTOR_H
#define IMAGEVECTOR_H

#include <QImage>
#include <QPoint>
#include <QDebug>
#include "imageattributes.h"

#define PIC_SIZEs 640 //размер загружаемого фото в памяти, по которому определяются признаки
#define PIC_PART 32//кол-во блоков в ряду и столбце

class ImageVector
{
public:
    //трансформация изображения
    static QImage prepareImage(const QImage& loadedImage, const QPoint& eye1, const QPoint& eye2, unsigned int picSize)
    {
        QImage imageTransformated = QImage(picSize, picSize, QImage::Format_RGB32); //создается в памяти изображение указанного размера
        QPoint p(eye2.x() - eye1.x(), eye2.y() - eye1.y()); //расстояние между глазами

        double angle = -1 * atan2(p.y(), p.x()); //угол между глазами
        double scale = (picSize / 3) / sqrt(p.x() * p.x() + p.y() * p.y()); //отношение расстояния между глазам к идеальному расстоянию (1/3 фото)
        //заливка пустого изображения черным
        imageTransformated.fill(Qt::black);
        //перебор пикселей в результирующем изображении и построение проекции на реальное изображение
        for (int x = 0; x < imageTransformated.size().width(); ++x)
        {
            for (int y = 0; y < imageTransformated.size().height(); ++y)
            {
                double x1 = (x - imageTransformated.size().width() / 4); // сдвигаем итоговое изображения тaк, чтобы глаз оказался в нуле
                double y1 = (y - imageTransformated.size().height() / 3);

                double x2 = x1 / scale; // масштабируем в обратную сторону
                double y2 = y1 / scale;

                double x3 = x2 * cos(-angle) - y2 * sin(-angle); // поворачиваем в обратную сторону
                double y3 = x2 * sin(-angle) + y2 * cos(-angle);

                double x4 = x3 + eye1.x(); // ставим глаз в исходное положение
                double y4 = y3 + eye1.y();

                int xFin = (int)round(x4); //округление координат
                int yFin = (int)round(y4);
                //пропускаем пиксели, которые не влазят в оригинал
                if (((xFin >= 0) && (xFin < loadedImage.size().width())) && ((yFin >= 0) && (yFin < loadedImage.size().height())))
                    imageTransformated.setPixel(x, y, loadedImage.pixel(xFin, yFin));

            }

        }
        return imageTransformated;
    }


    static ImageAttributes* calculateAttributes(const QImage& image)
    {

        int min = 256;
        int max = -1;
        QImage imageGrey = QImage(image.size().width(), image.size().height(), QImage::Format_Grayscale8); //создается в памяти изображение для сохранеия серого
        //пробегаем писксели оригинального изображения
        for (int x = 0; x < image.size().width(); ++x)
        {
            for (int y = 0; y < image.size().height(); ++y)
            {

               QRgb qRgb = image.pixel(x,y); //получаем значения цвета пикселя
               int newRgb = qGray(qRed(qRgb), qGreen(qRgb), qBlue(qRgb)); //устанавливаем цвет пикселя в сером изображении
               QColor c = QColor(newRgb, newRgb, newRgb);
               imageGrey.setPixelColor(x, y, c);

               if (newRgb < min)
                   min = newRgb;

               if (newRgb > max)
                   max = newRgb;
            }
        }
        max -= min;
        //делим изображение на части (16х16)
        QVector<QImage> parts;
        for(int i = 0; i < PIC_PART; ++i)
        {
            for(int j = 0; j < PIC_PART; ++j)
            {
                //копирование участка с координатами (верхнего левого угла и размера)
                QImage image = imageGrey.copy(i*(imageGrey.size().width()/PIC_PART), j*(imageGrey.size().height()/PIC_PART), imageGrey.size().width()/PIC_PART, imageGrey.size().height()/PIC_PART);
                parts.push_back(image); //сохранение в массив
            }
        }
        //создание класса атрибутов
        ImageAttributes* resultAttributes = new ImageAttributes(PIC_PART*PIC_PART);


        double matrix16[4][4]; //текущий блок
        unsigned short filters [16]; //фильтры
        filters[0] = 0xFFFF;
        filters[1] = 0x3333;
        filters[4] = 0x6666;
        filters[9] = 0xAAAA;
        filters[2] = 0xFF00;
        filters[3] = 0x33CC;
        filters[6] = 0x6699;
        filters[11] = 0xAA55;
        filters[5] = 0x0FF0;
        filters[7] = 0xC33C;
        filters[8] = 0x9669;
        filters[13] = 0x5AA5;
        filters[10] = 0x0F0F;
        filters[12] = 0xC3C3;
        filters[14] = 0x9696;
        filters[15] = 0x5A5A;

        //для каждого блока от 0 до размера массива
        for(int block = 0; block < parts.size(); ++block)
        {
            //очищение матрицы
            for (int i = 0; i < 4; ++i)
                for(int j = 0; j < 4; ++j)
                    matrix16[i][j] = 0;
            //проход по пикселям внутри блока
            for (int x = 0; x < parts[block].size().width(); ++x)
            {
                for (int y = 0; y < parts[block].size().height(); ++y)
                {
                    QRgb qrgb =  parts[block].pixel(x,y); //получение цвета пикселя
                    //суммированное нормальзованное значение (Q-преобразование)
                    matrix16[x/(parts[block].size().width()/4)][y/(parts[block].size().height()/4)] += (double)(qRed(qrgb) - min)/(double)max;
                }
            }

            double sumF = 0; //переменная хранит значение признака
            //применение фильтров
            for (int f = 0; f < 16; ++f)
            {
                sumF = 0;
                for (int i = 0; i < 4; ++i)
                {
                    for (int j = 0; j < 4; ++j)
                    {
                        if (((filters[f] >> (j*4+i)) & 0x01) == 0x01)
                            sumF += matrix16[i][j];
                        else
                            sumF -= matrix16[i][j];

                    }
                }
                //установка атрибута
                resultAttributes->setAttribute(block, f, sumF);
            }
        }

        return resultAttributes;
    }

};

#endif // IMAGEVECTOR_H
